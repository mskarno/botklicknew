# BOT kicknew telegram Edited V.2 Login Token

 Catatan : 

- Bot Ini Menggunakan hanya buat bot ltc & bch bitcoin Cara Install Via Android :

 - Download Termux & Install<br>
 - pkg install python<br>
 - pkg install php<br> 
 - pip install --upgrade pip
 - pip install rsa<br> 
 - pip install -r requests.txt<br>
 - pkg install git<br>
 - pkg install nano<br>
 - git clone https://github.com/mskarno/botklicknew<br> 
 - unzip bchnew.zip
 - Selesai 

Cara Membuka/Mengedit File :
 - cd bchnew && nano main.py<br>
 - Selesai Edit Save CTRL + X Lalu Y, Dan Enter<br>
 - Keluarkan Termux<br> 

Cara Menjalankan Bot 
 - cd bchnew && python main.py ( nomer phone)<br>
 - Cohtoh python main.py +6282288165322 Oke semoga bermanfaat. # . . . . . . 